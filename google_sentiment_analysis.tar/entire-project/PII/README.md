### Personally Identifiable information (PII) : masks personal information present
Install the dependencies in a virtual environment and execute the python script client.py
```bash 
$ source activate components  # To create a new virtual environment : *conda create -n <env_name>*
$ pip install -r requirements.txt
$ python client.py
```